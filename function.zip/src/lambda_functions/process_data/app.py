import json
import boto3
from dotenv import load_dotenv
load_dotenv()
endpoint = os.getenv('AWS_ENDPOINT_URL','https://s3.awazonaws.com')
bucket_name = os.getenv('NAME_BUCKET_RAW')
object_key = 'latest_data.json'
s3_client = boto3.client(
    's3',
    endpoint_url=endpoint,
    aws_access_key_id='test',
    aws_secret_access_key='test',
    region_name='us-east-1'
)
def lambda_transfer(event,context):
    try:
        response = s3.get_object(Bucket = bucket_name,Key = object_key)
        file_content = response['Body'].read().decode('utf-8')
        print(file_content)
    except Exception as e:
        print(f"Co loi: {e}!")
