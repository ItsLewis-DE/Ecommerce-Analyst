import json
import boto3
import os
s3_client = boto3.client('s3')
bucket_name = os.getenv('NAME_BUCKET_RAW','job-raw-bucket')
key = os.getenv('KEY','latest_data.json')
def lambda_transfer(event,context):
    response = s3_client.get_object(Bucket = bucket_name,Key=key)
    file_content = response['Body'].read().decode('utf-8')
    data = json.loads(file_content)
    return data

